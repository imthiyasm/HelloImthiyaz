<?php
date_default_timezone_set('Asia/Kolkata'); //e.g. date_default_timezone_set('Asia/Kolkata');
echo date("d");
?>
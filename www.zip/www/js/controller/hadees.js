myApp.controller('hadeesCtrl',['$scope', '$filter', '$http', '$log', '$routeParams', 'areaSelection_Service', 'commonService', 'localStorageService', function($scope, $filter, $http, $log, $routeParams, areaSelection_Service, commonService, localStorageService){
	$scope.$parent.headerView = true;
	$scope.hadeesName = $routeParams.hadeesName;
	$scope.hadeesList = [];
	$scope.getHadees = function(url){
	    $http.get(url)
        .success(function(data){
            angular.forEach(data.hadees[bukari], function(key, value) {
                alert(value);
            });
            /* $scope.said = data.hadeesDay[$scope.currentDate].said;
            $scope.hadees = data.hadeesDay[$scope.currentDate].hadees;
            $scope.introducer = data.hadeesDay[$scope.currentDate].introducer;
            $scope.book = data.hadeesDay[$scope.currentDate].book; */
        })
        .error(function(err){
            alert("Final Error");
        })
	}
	if( (platform == 'Android') || (platform == 'iOS') || (platform == 'WinCE') || (platform == 'Win32NT') ){
	        if( networkStatus == 'onLine'){
                var url = 'https://api.myjson.com/bins/ltba';
	        }else{
	            var url = './json/hadees.json';
            }
            $scope.getHadees(url);
    }
 }]);
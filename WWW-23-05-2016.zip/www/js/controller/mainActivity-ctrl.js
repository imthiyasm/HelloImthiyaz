/* Main activity controller */
myApp.controller('mainActivity', ['$scope', '$filter', '$http', '$log', '$location', function($scope, $filter, $http, $log, $location){
	$scope.headerView = false;
}]);
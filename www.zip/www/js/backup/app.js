var myApp = angular.module('mosque', ['ngRoute', 'ui.router', 'ui.bootstrap']);

myApp.config(function($routeProvider, $locationProvider){
	$routeProvider
	.when('/Login',{
		templateUrl : 'partials/login.html',
		controller : 'loginForm'
	})
    .when('/Register',{
		templateUrl : 'partials/signUp.html',
		controller : 'signUpForm'
	})
	.when('/Main',{
		templateUrl : 'partials/main.html',
		controller : 'mainActivity'
	})
    .otherwise({
        redirectTo : '/Main' 
    });
	
	//check browser support
    /*if(window.history && window.history.pushState){
        $locationProvider.html5Mode(true); will cause an error $location in HTML5 mode requires a  tag to be present! Unless you set baseUrl tag after head tag like so: <head> <base href="/">

        // to know more about setting base URL visit: https://docs.angularjs.org/error/$location/nobase

        // if you don't wish to set base URL then use this
        $locationProvider.html5Mode({
             enabled: true,
             requireBase: false
        });
    }*/
	
});

myApp.config(function($stateProvider, $urlRouterProvider){
	$urlRouterProvider.otherwise('/hadeesDay');
	$stateProvider
	.state('hadeesDay',{
		url: '/hadeesDay',
		templateUrl: 'partials/MainHTML-Nested-Branches/hadees-of-the-day.html'
	})
});